package com.library.repository;

public class BookRepository {
    public void save() {
        // Implementation of repository logic
        System.out.println("BookRepository is saving a book.");
    }
}
