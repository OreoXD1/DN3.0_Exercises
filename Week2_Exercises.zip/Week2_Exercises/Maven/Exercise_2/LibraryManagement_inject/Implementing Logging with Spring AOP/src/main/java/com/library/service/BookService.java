package com.library.service;

import com.library.repository.BookRepository;

public class BookService {

    private BookRepository bookRepository;

    // Getter method for BookRepository
    public BookRepository getBookRepository() {
        return bookRepository;
    }

    // Setter method for BookRepository
    public void setBookRepository(BookRepository bookRepository) {
        this.bookRepository = bookRepository;
    }

    // Example method to demonstrate functionality
    public void addBook(String bookName) {
        bookRepository.addBook(bookName);
        System.out.println("Service method called: Book " + bookName + " added.");
    }
}
