package com.library.service;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import com.library.service.BookService;

import java.util.Scanner;

public class LibraryManagementApplication {

    public static void main(String[] args) {
        // Load the Spring context
        ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");

        // Get the BookService bean
        BookService bookService = (BookService) context.getBean("bookService");

        // Get user input
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the name of the book to add: ");
        String bookName = scanner.nextLine();

        // Call a method on bookService to add the book
        bookService.addBook(bookName);
    }
}

