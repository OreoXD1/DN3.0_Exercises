package com.library.repository;

public class BookRepository {
    public void addBook(String bookName) {
        System.out.println("Book " + bookName + " added to repository.");
    }

    // Other repository methods
}
